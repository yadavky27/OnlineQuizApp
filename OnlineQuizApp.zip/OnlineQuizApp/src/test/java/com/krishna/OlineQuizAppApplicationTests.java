package com.krishna;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OlineQuizAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
