package com.krishna.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.krishna.model.Question;
import com.krishna.model.Quiz;
import com.krishna.repository.QuizRepository;

@Service
public class QuizService {
    @Autowired
    private QuizRepository quizRepository;

    public List<Quiz> getAllQuizzes() {
        return quizRepository.findAll();
    }

   
    public void saveQuiz(Quiz quiz) {
        quizRepository.save(quiz);
    }

    public Optional<Quiz> getQuizById(Long id) {
        return quizRepository.findById(id);
    }
    
    public int calculateScore(Long quizId, Map<String, String> answers) {
        // Fetch the quiz by ID
        Quiz quiz = quizRepository.findById(quizId)
                .orElseThrow(() -> new IllegalArgumentException("Quiz not found"));

        int score = 0;

        // Loop through each question in the quiz
        for (Question question : quiz.getQuestions()) {
            // Get the user's answer for the current question
            String userAnswer = answers.get("question_" + question.getId());
            String correctAnswer=question.getCorrectOption();
            // Debug logs for verification
            System.out.println("Question ID: " + question.getId());
            System.out.println("User Answer: " + userAnswer);
            System.out.println("Correct Answer: " + question.getCorrectOption());
              System.out.println(answers);
            while(userAnswer.equals(correctAnswer))
            {
            	
            	System.out.println("ddddddd");
            	score++;
            	break;
            }
        }

        System.out.println("Final Score: " + score); // Debug log
        return score;
    }
   

    public void deleteQuiz(Long id) {
        // Check if the quiz exists
        if (!quizRepository.existsById(id)) {
            throw new RuntimeException("Quiz not found with id: " + id);
        }
        // Delete the quiz
        quizRepository.deleteById(id);
    }
}
