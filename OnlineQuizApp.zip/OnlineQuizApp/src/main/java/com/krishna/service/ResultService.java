package com.krishna.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.krishna.model.Result;
import com.krishna.repository.ResultRepository;

@Service
public class ResultService {
    @Autowired
    private ResultRepository resultRepository;

    public List<Result> getLeaderboard(Long quizId) {
        return resultRepository.findTopResultsByQuizId(quizId);
    }
}