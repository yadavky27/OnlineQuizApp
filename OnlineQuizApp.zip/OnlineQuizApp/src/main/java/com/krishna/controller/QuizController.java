package com.krishna.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.krishna.model.Quiz;
import com.krishna.service.QuizService;

@Controller
@RequestMapping("/admin")
public class QuizController {

    @Autowired
    private QuizService quizService;

    @GetMapping("/quizzes")
    public String listQuizzes(Model model) {
        model.addAttribute("quizzes", quizService.getAllQuizzes());
        return "quiz-list";
    }

    @GetMapping("/quizzes/new")
    public String createQuizForm(Model model) {
        model.addAttribute("quiz", new Quiz());
        return "quiz-form";
    }

    @PostMapping("/quizzes")
    public String saveQuiz(@ModelAttribute Quiz quiz) {
        quizService.saveQuiz(quiz);
        return "redirect:/admin/quizzes";
    }
    
    @GetMapping("/quizzes/edit/{id}")
    public String editQuizForm(@PathVariable Long id, Model model) {
        model.addAttribute("quiz", quizService.getQuizById(id).orElseThrow(() -> new RuntimeException("Quiz not found")));
        return "quiz-form";
    }

    @GetMapping("/quizzes/delete/{id}")
    public String deleteQuiz(@PathVariable Long id) {
        quizService.deleteQuiz(id);
        return "redirect:/admin/quizzes";
    }
}
