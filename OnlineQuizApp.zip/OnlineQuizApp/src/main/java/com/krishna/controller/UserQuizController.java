package com.krishna.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.krishna.model.Quiz;
import com.krishna.model.User;
import com.krishna.service.QuizService;
import com.krishna.service.UserService;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

@Controller
@RequestMapping("/user")
public class UserQuizController {

    @Autowired
    private QuizService quizService;
    
    @Autowired
    private UserService userService;

    @GetMapping("/")
    public String UserHomePageShowForm()
    {
    	return "user-home-page";
    }
    
    @GetMapping("/user-profile")
    public String getUserProfile(Model model) {
        // Get the logged-in username from SecurityContext
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();  // This is the logged-in user's username

        // Fetch user details using the username
        User user = userService.getUserByUsername(username);

        // Add user data to the model
        model.addAttribute("user", user);

        // Return the profile view
        return "user-profile"; // Thymeleaf template for the profile page
    }
    
    @GetMapping("/profile-edit")
    public String UserProfileEdit()
    {
    	return "user-profile-edit";
    }
    
    @PostMapping("/user-profile-edit-form")
    public String UserProfileHandler(User user,Model model)
    {
    	System.out.println(user);
    	userService.createUser(user);
    	return "user-profile";
    }
    @GetMapping("/user-list")
    public String showUserQuizList(Model model) {
        List<Quiz> quizzes = quizService.getAllQuizzes();

        // Check if the list is empty and handle gracefully
        if (quizzes.isEmpty()) {
            model.addAttribute("errorMessage", "No quizzes available at the moment.");
            return "user-quiz-list"; // Handle the empty state in the template
        }

        model.addAttribute("quizzes", quizzes);
        return "user-quiz-list";
    }
    
    
    @GetMapping("/take/{id}")
    public String takeQuiz(@PathVariable Long id, Model model) {
        Quiz quiz = quizService.getQuizById(id).orElseThrow(() -> new RuntimeException("Quiz not found"));
        model.addAttribute("quiz", quiz);
        return "take-quiz";
    }

    @PostMapping("/submit")
    public String submitUserData(@RequestParam Long quizId,@RequestParam Map<String, String> answer,Model model) {
        // Handle POST request
    	System.out.println(answer);
    	  int score = quizService.calculateScore(quizId, answer);
          
          // Add the score to the model for display
          model.addAttribute("ans", score);
    	
        return "quiz-result";
    }
}