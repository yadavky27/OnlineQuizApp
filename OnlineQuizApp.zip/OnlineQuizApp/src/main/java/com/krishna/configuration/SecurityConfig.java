package com.krishna.configuration;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;



@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/admin/**").hasRole("ADMIN")  // Only users with the ADMIN role can access /admin/** URLs
                .requestMatchers("/user/**").hasRole("USER")    // Only users with the USER role can access /user/** URLs
                .anyRequest().permitAll()  // All other requests are publicly accessible
            )
            .formLogin()  // Enables default login form
            .and()
            .csrf().disable();  // Disables CSRF protection (consider enabling it if needed)
        return http.build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();  // Using BCryptPasswordEncoder for password encryption
    }

    @Bean
    public UserDetailsService userDetailsService() {
        // Create the admin user with the ADMIN role
        UserDetails admin = User.builder()
            .username("admin")
            .password(passwordEncoder().encode("admin"))  // Encode the admin password
            .roles("ADMIN")  // Admin role
            .build();

        // Create the regular user with the USER role
        UserDetails user = User.builder()
            .username("user")
            .password(passwordEncoder().encode("user"))  // Encode the user password
            .roles("USER")  // User role
            .build();

        // Return both users (admin and regular user) with InMemoryUserDetailsManager
        return new InMemoryUserDetailsManager(admin, user);
    }
}
