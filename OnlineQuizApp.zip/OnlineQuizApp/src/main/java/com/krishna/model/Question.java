package com.krishna.model;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Question {

	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	 private String title;
     private List<String> options;
	    private String correctAnswer;
		
	    private String correctOption;
	    
		public String getCorrectOption() {
			return correctOption;
		}



		public void setCorrectOption(String correctOption) {
			this.correctOption = correctOption;
		}



		public Long getId() {
			return id;
		}



		public void setId(Long id) {
			this.id = id;
		}



		public String getTitle() {
			return title;
		}



		public void setTitle(String title) {
			this.title = title;
		}



		public List<String> getOptions() {
			return options;
		}



		public void setOptions(List<String> options) {
			this.options = options;
		}



		public String getCorrectAnswer() {
			return correctAnswer;
		}



		public void setCorrectAnswer(String correctAnswer) {
			this.correctAnswer = correctAnswer;
		}



		public Question() {
			super();
			// TODO Auto-generated constructor stub
		}
	    
	    
}
